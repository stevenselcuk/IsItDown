//
//  Constants.swift
//  StatusChecker
//
//  Created by Steven J. Selcuk on 17.08.2022.
//

import Foundation

struct Constants {
      // Helper Application Bundle Identifier
      static let helperBundleID = "org.tabbycatllc.IsItDownAutoLauncher"
  }
